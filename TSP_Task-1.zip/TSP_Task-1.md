# The Spark Foundation Internship
Data Science and Business Analytics

# Name - Mukund Shrikant Mane

# Task - 1

# Prediction using Supervised ML
Predict percentage of a students based on the number of study hours.

Data can be found at - http://bit.ly/w-data

What will be predicted score id student studies for 9.25hrs/day?


```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn import preprocessing
%matplotlib inline

print("The libraries as imported!")
```

    The libraries as imported!
    


```python
url="http://bit.ly/w-data"
df=pd.read_csv(url)
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Hours</th>
      <th>Scores</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2.5</td>
      <td>21</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5.1</td>
      <td>47</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3.2</td>
      <td>27</td>
    </tr>
    <tr>
      <th>3</th>
      <td>8.5</td>
      <td>75</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3.5</td>
      <td>30</td>
    </tr>
    <tr>
      <th>5</th>
      <td>1.5</td>
      <td>20</td>
    </tr>
    <tr>
      <th>6</th>
      <td>9.2</td>
      <td>88</td>
    </tr>
    <tr>
      <th>7</th>
      <td>5.5</td>
      <td>60</td>
    </tr>
    <tr>
      <th>8</th>
      <td>8.3</td>
      <td>81</td>
    </tr>
    <tr>
      <th>9</th>
      <td>2.7</td>
      <td>25</td>
    </tr>
    <tr>
      <th>10</th>
      <td>7.7</td>
      <td>85</td>
    </tr>
    <tr>
      <th>11</th>
      <td>5.9</td>
      <td>62</td>
    </tr>
    <tr>
      <th>12</th>
      <td>4.5</td>
      <td>41</td>
    </tr>
    <tr>
      <th>13</th>
      <td>3.3</td>
      <td>42</td>
    </tr>
    <tr>
      <th>14</th>
      <td>1.1</td>
      <td>17</td>
    </tr>
    <tr>
      <th>15</th>
      <td>8.9</td>
      <td>95</td>
    </tr>
    <tr>
      <th>16</th>
      <td>2.5</td>
      <td>30</td>
    </tr>
    <tr>
      <th>17</th>
      <td>1.9</td>
      <td>24</td>
    </tr>
    <tr>
      <th>18</th>
      <td>6.1</td>
      <td>67</td>
    </tr>
    <tr>
      <th>19</th>
      <td>7.4</td>
      <td>69</td>
    </tr>
    <tr>
      <th>20</th>
      <td>2.7</td>
      <td>30</td>
    </tr>
    <tr>
      <th>21</th>
      <td>4.8</td>
      <td>54</td>
    </tr>
    <tr>
      <th>22</th>
      <td>3.8</td>
      <td>35</td>
    </tr>
    <tr>
      <th>23</th>
      <td>6.9</td>
      <td>76</td>
    </tr>
    <tr>
      <th>24</th>
      <td>7.8</td>
      <td>86</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Hours</th>
      <th>Scores</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2.5</td>
      <td>21</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5.1</td>
      <td>47</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3.2</td>
      <td>27</td>
    </tr>
    <tr>
      <th>3</th>
      <td>8.5</td>
      <td>75</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3.5</td>
      <td>30</td>
    </tr>
  </tbody>
</table>
</div>



# Cheaking for Null Values 


```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 25 entries, 0 to 24
    Data columns (total 2 columns):
     #   Column  Non-Null Count  Dtype  
    ---  ------  --------------  -----  
     0   Hours   25 non-null     float64
     1   Scores  25 non-null     int64  
    dtypes: float64(1), int64(1)
    memory usage: 528.0 bytes
    

# Description of the Dataset


```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Hours</th>
      <th>Scores</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>25.000000</td>
      <td>25.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>5.012000</td>
      <td>51.480000</td>
    </tr>
    <tr>
      <th>std</th>
      <td>2.525094</td>
      <td>25.286887</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.100000</td>
      <td>17.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>2.700000</td>
      <td>30.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>4.800000</td>
      <td>47.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>7.400000</td>
      <td>75.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>9.200000</td>
      <td>95.000000</td>
    </tr>
  </tbody>
</table>
</div>



# Visualizing the Data 


```python
df.plot(kind='scatter',x='Hours',y='Scores')
plt.show()
```


    
![png](output_12_0.png)
    


# Preparing the data by splitting it into train and Test set


```python
x = df.iloc[:,:-1].values
y = df.iloc[:,1].values
```


```python
#Spilitting the data into train and test
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test=train_test_split(x, y, test_size=0.2, random_state=42)
print('The Train and test data are prepared !!')
```

    The Train and test data are prepared !!
    


```python
x_train
```




    array([[2.7],
           [3.3],
           [5.1],
           [3.8],
           [1.5],
           [3.2],
           [4.5],
           [8.9],
           [8.5],
           [3.5],
           [2.7],
           [1.9],
           [4.8],
           [6.1],
           [7.8],
           [5.5],
           [7.7],
           [1.1],
           [7.4],
           [9.2]])




```python
plt.scatter(x_train ,y_train ,label='Training data', color='orange')
plt.scatter(x_test ,y_test ,label='Testing data', color='cyan')
plt.legend
plt.title('Model Visualization')
plt.show()
```


    
![png](output_17_0.png)
    


# Using Linear Regression Alogorithm


```python
from sklearn.linear_model import LinearRegression
model = LinearRegression()
model.fit(x_train, y_train)
```




    LinearRegression()



# Predecting the Test Datasets


```python
pred = model.predict(x_test)
pred
```




    array([83.18814104, 27.03208774, 27.03208774, 69.63323162, 59.95115347])




```python
pred1 = pd.DataFrame(pred)
pred1
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>83.188141</td>
    </tr>
    <tr>
      <th>1</th>
      <td>27.032088</td>
    </tr>
    <tr>
      <th>2</th>
      <td>27.032088</td>
    </tr>
    <tr>
      <th>3</th>
      <td>69.633232</td>
    </tr>
    <tr>
      <th>4</th>
      <td>59.951153</td>
    </tr>
  </tbody>
</table>
</div>



# Plotting the Test Data


```python
# Plotting the Regression line
line = model.coef_*x+model.intercept_
# Plotting for the test Data
plt.scatter(x,y)
plt.plot(x,line)
plt.show()
```


    
![png](output_24_0.png)
    



```python
# Import Library to cheak Accuracy
from sklearn.metrics import mean_absolute_error
score = mean_absolute_error(y_test, pred)
print(score)
```

    3.9207511902099244
    

# Test with hours = 9.25


```python
hr = np.array([9.25]).reshape(1,-1)
p = model.predict(hr)
print('Student studies for 9.25 hrs/day')
print('Score of student = {}'.format(p[0]))
```

    Student studies for 9.25 hrs/day
    Score of student = 92.38611528261494
    

# Result

If a student studies for 9.25 hours per day then he scores 92.38611


```python

```
